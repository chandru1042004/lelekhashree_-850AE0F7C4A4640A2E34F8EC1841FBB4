''' Implement a class called player that represents a cricket player.The player class should have a
method called play()which printa "The player is playing cricket.  Derive two classes, Batsman and
Bowler, from the player class.  Override the play() method in each derived class to print "The batsman
is batting" aand " The bowler is bowling", respectively.
writw a program to create objecta of both the
Batsman andbowler classes and call the play() method for object.'''

#Define the base class player
class player:
  def play(self):
    print("The player is playing cricket.")

#Define the derived class Batsman
class Batsman(player):
  def play(self):
    print("The batsman is batting.")

#Define the derived class bowler
class bowler(player):
  def play(self):
    print("The bowler is bowling.")

#create objects of Batsman and Bowler classes
batsman = Batsman()
bowler = bowler

#call the play()method for each object
batsman.play()
bowler.play

          